package tracker.controllers.model.util;

public enum Status {
    NEW,
    IN_PROGRESS,
    DONE
}
